<?php

namespace App\Helpers;


use App\Location;
use App\User_profile;
use App\User;
use App\Location_user;
use App\Site_user;
use DB;
use Carbon\Carbon;
use Auth;
use Session;

class Helper {


    public static function get_logged_in_user() 
    {
      if(isset(Auth::user()->id))
          return Auth::user()->id;
      else
        return Session::get('loggedin_user');
    }

    public static function get_logged_in_user_role($id) 
    {
      if($id)
      {
          $user = User::find($id);
          if($user)
          {
            return $user['role'];
          }
          else
            return "NA";
      }
      else
        return "NA";      
    }

    public static function get_logged_in_user_company($id) 
    {
      if($id)
      {
          $user = User::find($id);
          if($user)
          {
            return $user['company_id'];
          }
          else
            return "NA";
      }
      else
        return "NA";      
    }

    public static function get_logged_in_user_type($id) 
    {
      if($id)
      {
          $user = User_profile::where('user_id', $id)->first();
          if($user)
          {
            return $user['user_type'];
          }
          else
            return "NA";
      }
      else
        return "NA";      
    }

    public static function get_mapped_user($company_id, $location_id) 
    {
      $map = "";
      $users = Location_user::select("users.name as user_name", "user_profiles.user_type")
        ->leftjoin("users", "location_users.user_id", "=", "users.id")
        ->leftjoin("user_profiles", "users.id", "=", "user_profiles.user_id")
        ->where("location_users.is_active", 1)
        ->where("location_users.company_id", $company_id)
        ->where("location_users.location_id", $location_id)
        ->get();
        if($users)
        {
          $user_arr = array(); 
          foreach($users as $row)
          {
            array_push($user_arr, $row->user_name."- User Type ".$row->user_type);
          }
          if($user_arr)
          {
            $map = implode("<br>", $user_arr);
          }
        }
        return $map;
    }

    public static function get_sites_mapped_user($company_id, $site_id) 
    {
      $map = "";
      $users = Site_user::select("users.name as user_name", "user_profiles.user_type")
        ->leftjoin("users", "site_users.user_id", "=", "users.id")
        ->leftjoin("user_profiles", "users.id", "=", "user_profiles.user_id")
        ->where("site_users.is_active", 1)
        ->where("site_users.company_id", $company_id)
        ->where("site_users.site_id", $site_id)
        ->get();
        if($users)
        {
          $user_arr = array(); 
          foreach($users as $row)
          {
            array_push($user_arr, $row->user_name."- User Type ".$row->user_type);
          }
          if($user_arr)
          {
            $map = implode("<br>", $user_arr);
          }
        }
        return $map;
    }

    public static function get_location_name($id) 
    {
      $name = Location::select('name')->where('id', $id)->first();
      return $name['name'];
    }

    public static function get_role($id) 
    {
      $role = User::select('role')->where('id', $id)->first();
      return $role['role'];
    }


    public static function get_trainer_region($id) 
    {
      $rehions_name = "";
      if($id)
      {
        $regions_name_array = array();
        $regions = User_Region::leftjoin("locations", "user_regions.region_id", "=", "locations.id")
          ->select('locations.name')
          ->orderBy("locations.name", "ASC")
          ->where('user_regions.user_id',$id)
          ->where('user_regions.is_active', 1)
          ->get();
        if(count($regions))
        {
          foreach ($regions as $row) 
          {
            array_push($regions_name_array, $row->name);
          }
          if($regions_name_array)
            $rehions_name = implode(", ", $regions_name_array);
          //$sections_name = "<ul><li>".implode("</li><li>", $sections_name_array)."</li></ul>";
        }
      }
      return $rehions_name;
    }

    public static function get_batch_dates($id) 
    {
      $result = "";
      if($id)
      {
        $dates = Batch_date::select("start_date","end_date")
        ->where('plan_id', $id)
        ->get();
        if($dates)
        {
          $result .= "<ul>";
          foreach($dates as $row)
          {
              $result .= "<li>Start Date : ".Carbon::parse($row->start_date)->format('d-m-Y')." End Date : ".Carbon::parse($row->end_date)->format('d-m-Y')." </li>";
          }
          $result .= "</ul>";
        }

      }
      return $result;
    }


    public static function get_emplyee_id_from_name($name) 
    {
      $name = User::select('id')->where('name', $name)->first();
      return $name['id'];
    }


    /*---------------*/


    public static function get_emplyee_name_from_code($id) 
    {
      $name = User_profile::select('first_name', 'last_name')->where('emp_code', $id)->first();
      return $name['first_name']." ".$name['last_name'];
    }

    public static function get_emplyee_id_from_code($id) 
    {
      $name = User_profile::select('user_id')->where('emp_code', $id)->first();
      return $name['user_id'];
    }

    public static function get_emplyee_name_from_id($id) 
    {
      if($id)
      {
        $name = User_profile::select('first_name', 'last_name')->where('reporting_to', $id)->first();
        return $name['first_name']." ".$name['last_name'];
      }
      else
      {
        return "NA";
      }
    }

    public static function get_current_quarter() 
    {
        $start_date = "";
        $end_date = "";
        $month = date('n');

        if($month >= 1 && $month <= 3)
        {
            $start_date = date('Y')."-01-01";
            $end_date = date('Y')."-03-31";
        }
        elseif($month >= 4 && $month <= 6) 
        {
            $start_date = date('Y')."-04-01";
            $end_date = date('Y')."-06-30";
        }
        elseif($month >= 7 && $month <= 9) 
        {
            $start_date = date('Y')."-07-01";
            $end_date = date('Y')."-09-30";
        }
        else
        {
            $start_date = date('Y')."-10-01";
            $end_date = date('Y')."-12-31";
        }
        
        $quarter = Quarters::where('start_date', $start_date)
        ->where('end_date', $end_date)
        ->first();

        return $quarter->id;
    }


    public static function get_emplyee_skill_rating($user_id, $skill_id, $quarter_id) 
    {
      $rating = Employee_skill_rating::select('rating')
      ->where('user_id', $user_id)
      ->where('skill_id', $skill_id)
      ->where('quarter_id', $quarter_id)
      ->first();
      return $rating['rating'];
    }

    public static function get_max_id_plan($plan_id) 
    {
      $id = Batch_date::where('plan_id', $plan_id)
      ->max('id');
      return $id;
    }

    public static function get_average($batch_date_max_id) 
    {
      $res = DB::select("SELECT SUM(temp.SD) as sum , COUNT( DISTINCT temp.stu) AS c  FROM (SELECT `trainer_id` AS trainer_id, `batch_id` AS b, `company_id` AS com, `student_id` AS stu, SUM(`rating`)/6 AS SD FROM `student_feedbacks` WHERE `option_id` <=6 AND `batch_date_id` = $batch_date_max_id GROUP BY `batch_date_id`,`student_id`) AS temp");
      $sum = 0;
      $count = 0;
      $avg = 0;
      if($res)
      {
        foreach($res as $row)
        {
          $sum = $row->sum;
          $count = $row->c;
          if($sum && $count)
          {
            $avg = $sum/$count;
            $avg = round($avg,2);            
          }
        }
      }
      return $avg;
    }
}
