<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Agent_commission_log extends Model
{
    //
}
