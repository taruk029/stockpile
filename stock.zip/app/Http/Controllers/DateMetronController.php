<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Pile;
use App\Site;
use App\Location;
use App\Date_metron;
use DB;
use App\Helpers\Helper;
use Auth;

class DateMetronController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {        
        $loggedin_user = Helper::get_logged_in_user();
    	$dates_metron = Date_metron::leftjoin("piles", "date_metrons.pile_id", "=", "piles.id")
    	->select("date_metrons.*", "piles.pile_name", "piles.pile_reference_id")
    	->where('date_metrons.user_id', $loggedin_user)
    	->get();
        return view('dates_metron.index', ['dates_metron'=>$dates_metron, 'loggedin_user'=>$loggedin_user]);
    }

    public function add()
    {
        $loggedin_user = Helper::get_logged_in_user();

        $location = Location::select('id', 'name')
        ->select('locations.*', 'countries.name as country_name')
        ->leftjoin("countries", "locations.country", "=", "countries.id")
        ->where('locations.is_active', 1)
        ->orderBy('name', 'ASC')
        ->get();

        return view('dates_metron.add', ['location'=>$location, 'loggedin_user'=>$loggedin_user]);
    }

    public function get_staff_sites(Request $request)
    {
        $site = Site::where("location_id", $request->id)
            ->where("is_active", 1)
            ->select('id', 'name')
            ->orderBy('name', 'ASC')
            ->get();
            $data = array();
        for($i=0;$i<count($site);$i++){
           $data[] = array('id'=>$site[$i]->id,'name'=>$site[$i]->name);
        }
        $output  = $data;
        echo json_encode($output);
    }

    public function get_staff_piles(Request $request)
    {
        $pile = Pile::where("site_id", $request->id)
            ->where("is_active", 1)
            ->select('id', 'pile_name', 'pile_reference_id')
            ->orderBy('pile_name', 'ASC')
            ->get();
        $data = array();
        for($i=0;$i<count($pile);$i++){
           $data[] = array('id'=>$pile[$i]->id,'name'=>$pile[$i]->pile_name,'pile_reference_id'=>$pile[$i]->pile_reference_id);
        }
        $output  = $data;
        echo json_encode($output);
    }

    public function insert(Request $request)
    {
    	$request->validate([
            'pile' => 'required|numeric',
            'date' => 'required|string',            
            'method' => 'required|string'
        ]);

        $image_one_url = "";
        $images_one_fileName = "";
        if($request->hasFile('image_one'))
        {
            $images = $request->file('image_one');
            $images_one_fileName = rand(99,9999).date('Ymdhis').'.'.$images->getClientOriginalExtension();
            $images->move(base_path().'/public/date_metron/', $images_one_fileName);
            $image_one_url = url('/')."/public/date_metron/".$images_one_fileName;
        }

        $image_two_url = "";
        $images_two_fileName = "";
        if($request->hasFile('image_two'))
        {
            $images2 = $request->file('image_two');
            $images_two_fileName = rand(99,9999).date('Ymdhis').'.'.$images2->getClientOriginalExtension();
            $images2->move(base_path().'/public/date_metron/', $images_two_fileName);
            $image_two_url = url('/')."/public/date_metron/".$images_two_fileName;
        }
            $pile = Pile::find($request->pile);
        	$exd = date_create($request->date);
        	$date_metron = new Date_metron;
			$date_metron->user_id = Auth::user()->id;
            $date_metron->company_id = $pile['company_id'];
			$date_metron->location_id = $request->location;
            $date_metron->site_id = $request->site;
            $date_metron->pile_id = $request->pile;
            $date_metron->pile_type = $request->pile_type;
            $date_metron->date_of_survey = date_format($exd,'Y-m-d');
            $date_metron->start_time = $request->start_time;
            $date_metron->end_time = $request->end_time;
            $date_metron->method = $request->method;
            $date_metron->volume = $request->volume;
            $date_metron->toe_confidence = $request->toe_confidence;
            $date_metron->surface_confidence = $request->surface_confidence;
            $date_metron->combined_piles = $request->combined_piles;
            $date_metron->standing_water = $request->standing_water;
            $date_metron->debris = $request->debris;
            $date_metron->equipment_obstruction = $request->equipment_obstruction;
            $date_metron->vegetation = $request->vegetation;
            $date_metron->highwall = $request->highwall;
            $date_metron->lighting_issue = $request->lighting_issue;
            $date_metron->burried_base = $request->burried_base;
            $date_metron->ogl = $request->ogl;
            $date_metron->piles_covered_with_tarpolin = $request->piles_covered_with_tarpolin;
            $date_metron->comments = $request->comments;
            $date_metron->image_one = $images_one_fileName;
            $date_metron->image_one_url = $image_one_url;
            $date_metron->image_two = $images_two_fileName;
            $date_metron->image_two_url = $image_two_url;
            $date_metron->three_dmodel = $request->three_dmodel;
            $date_metron->save();
			flash('Date Metron has been added successfully.')->success();
    		return redirect('dates_metron'); 
    }

    public function edit($id)
    {
        $loggedin_user = Helper::get_logged_in_user();

        $date_metron = Date_metron::where('id', $id)->first();
   		
        $location = Location::select('id', 'name')
        ->select('locations.*', 'countries.name as country_name')
        ->leftjoin("countries", "locations.country", "=", "countries.id")
        ->where('locations.is_active', 1)
        ->orderBy('name', 'ASC')
        ->get();

        $site = Site::where("location_id", $date_metron['location_id'])
            ->where("is_active", 1)
            ->select('id', 'name')
            ->orderBy('name', 'ASC')
            ->get();

        $piles = Pile::where("site_id", $date_metron['site_id'])
            ->where("is_active", 1)
            ->select('id', 'pile_name', 'pile_reference_id')
            ->orderBy('pile_name', 'ASC')
            ->get();

        return view('dates_metron.edit', ['date_metron'=>$date_metron, 'location'=>$location, 'site'=>$site, 'piles'=>$piles, 'loggedin_user'=>$loggedin_user]);
    }

    public function update(Request $request)
    {
    	$request->validate([
            'pile' => 'required|numeric',
            'date' => 'required|string',            
            'method' => 'required|string'
        ]);

        $image_one_url = "";
        $images_one_fileName = "";
        if($request->hasFile('image_one'))
        {
            $old_pic_one = Date_metron::select('image_one')->where('id', $request->date_metron_id)->first();
            if($old_pic_one)
            {
                if(!empty($old_pic_one->image_one))
                {
                    $old_file = base_path().'/public/date_metron/'.$old_pic_one->image_one;
                    if(file_exists($old_file))
                    {
                        unlink($old_file);
                    }
                }
                $images = $request->file('image_one');
                $images_one_fileName = rand(99,9999).date('Ymdhis').'.'.$images->getClientOriginalExtension();
                $images->move(base_path().'/public/date_metron/', $images_one_fileName);
                $image_one_url = url('/')."/public/date_metron/".$images_one_fileName;
            }
        }

        $image_two_url = "";
        $images_two_fileName = "";
        if($request->hasFile('image_two'))
        {
            $old_pic_two = Date_metron::select('image_two')->where('id', $request->date_metron_id)->first();
            if($old_pic_two)
            {
                if(!empty($old_pic_two->image_two))
                {
                    $old_file2 = base_path().'/public/date_metron/'.$old_pic_two->image_two;
                    if(file_exists($old_file2))
                    {
                        unlink($old_file2);
                    }
                }
                $images2 = $request->file('image_two');
                $images_two_fileName = rand(99,9999).date('Ymdhis').'.'.$images2->getClientOriginalExtension();
                $images2->move(base_path().'/public/date_metron/', $images_two_fileName);
                $image_two_url = url('/')."/public/date_metron/".$images_two_fileName;
            }
        }

        $pile = Pile::find($request->pile);
		$exd = date_create($request->date);
    	$date_metron = Date_metron::find($request->date_metron_id);;
		$date_metron->company_id = $pile['company_id'];
        $date_metron->location_id = $request->location;
        $date_metron->site_id = $request->site;
		$date_metron->pile_id = $request->pile;
        $date_metron->pile_type = $request->pile_type;
        $date_metron->date_of_survey = date_format($exd,'Y-m-d');
        $date_metron->start_time = $request->start_time;
        $date_metron->end_time = $request->end_time;
        $date_metron->method = $request->method;
        $date_metron->volume = $request->volume;
        $date_metron->toe_confidence = $request->toe_confidence;
        $date_metron->surface_confidence = $request->surface_confidence;
        $date_metron->combined_piles = $request->combined_piles;
        $date_metron->standing_water = $request->standing_water;
        $date_metron->debris = $request->debris;
        $date_metron->equipment_obstruction = $request->equipment_obstruction;
        $date_metron->vegetation = $request->vegetation;
        $date_metron->highwall = $request->highwall;
        $date_metron->lighting_issue = $request->lighting_issue;
        $date_metron->burried_base = $request->burried_base;
        $date_metron->ogl = $request->ogl;
        $date_metron->piles_covered_with_tarpolin = $request->piles_covered_with_tarpolin;
        $date_metron->comments = $request->comments;
        if($request->hasFile('image_one'))
        {
            $date_metron->image_one = $images_one_fileName;
            $date_metron->image_one_url = $image_one_url;
        }
        if($request->hasFile('image_two'))
        {
            $date_metron->image_two = $images_two_fileName;
            $date_metron->image_two_url = $image_two_url;
        }
        $date_metron->three_dmodel = $request->three_dmodel;
        $date_metron->save();
		flash('Date Metron has been updated successfully.')->success();
		return redirect('dates_metron'); 
    }
}
