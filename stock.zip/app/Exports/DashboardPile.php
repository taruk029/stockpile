<?php

namespace App\Exports;


use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Maatwebsite\Excel\Events\BeforeSheet;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use App\Pile;
use App\Date_metron;
use App\Site_user;
use App\Helpers\Helper;

class DashboardPile implements FromCollection,WithHeadings,WithHeadingRow,WithEvents,ShouldAutoSize
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function __construct()
    {        
    }

    public function collection()
    {    	
    	$loggedin_user = Helper::get_logged_in_user();
        if($loggedin_user) 
        {
            $role = Helper::get_logged_in_user_role($loggedin_user);
            if($role==3)
            { 
                $sites = Site_user::select('site_id')->where('user_id',$loggedin_user)->get();
                $site_array = array();
                if($sites)
                {
                    foreach($sites as $row)
                    {
                        array_push($site_array, $row->site_id);
                    }
                }
                $piles = Pile::leftjoin("date_metrons", "date_metrons.pile_id", "=", "piles.id")
                ->leftjoin("locations", "locations.id", "=", "piles.location_id")
                ->leftjoin("sites", "sites.id", "=", "piles.site_id")
                ->select('date_metrons.id as date_metron_id', 'piles.pile_reference_id', 'piles.pile_name', 'piles.id as pileId', 'piles.bulk_density', 'piles.moisture', 'locations.name as location_name', 'sites.name as site_name', 'date_metrons.pile_type','date_metrons.start_time','date_metrons.end_time','date_metrons.volume','date_metrons.three_dmodel')
                ->whereIn('piles.site_id', $site_array)
                ->where("date_metrons.volume", "!=", "") 
                ->orderBy("piles.id", "desc")
                ->get();
            }
            else
            {
            	$piles = Pile::leftjoin("date_metrons", "date_metrons.pile_id", "=", "piles.id")
                    ->leftjoin("locations", "locations.id", "=", "piles.location_id")
                    ->leftjoin("sites", "sites.id", "=", "piles.site_id")
                    ->select('date_metrons.id as date_metron_id', 'piles.pile_reference_id', 'piles.pile_name', 'piles.id as pileId', 'piles.bulk_density', 'piles.moisture', 'locations.name as location_name', 'sites.name as site_name', 'date_metrons.pile_type','date_metrons.start_time','date_metrons.end_time','date_metrons.volume','date_metrons.three_dmodel')
                    ->where("date_metrons.company_id", $loggedin_user)
                    ->where("date_metrons.volume", "!=", "") 
                    ->orderBy("piles.id", "desc")
                    ->get();
            }

         	$data = array();
            foreach($piles as $row)
            {
                $start_time = "";
                $end_time = "";
                $tonnage ="BD/Moisture not entered";
                if($row->volume!="" && $row->moisture && $row->bulk_density) 
                {
                    $tonnage = (($row->volume*$row->bulk_density)*(1-$row->moisture));
                }
                $start_time = date_create($row->start_time);
                $end_time = date_create($row->end_time);
                $data[] = array("pile_code"=>$row->pile_reference_id, 
                        "location"=>$row->location_name, 
                        "site"=>$row->site_name, 
                        "pile_type"=>$row->pile_type, 
                        "pile_name"=>$row->pile_name,
                        "start_time"=>date_format($start_time,'h:i:s'),
                        "end_time"=>date_format($end_time,'h:i:s'),
                        "volume"=>$row->volume,
                        "tonnage"=>$tonnage,
                        "view_3d"=>$row->three_dmodel?$row->three_dmodel:"NA"
                );
            }
            return collect([ $data ]);
        }
    }

    public function registerEvents(): array {
      $styleArray=['font'=>['bold'=>true,'size'=>12,],
               'borders' => [
               'allborders' => [
               'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK,
               'color' => ['argb' => 'FF000000'],],],];


       return [
           AfterSheet::class    => function(AfterSheet $event) use ($styleArray) {

             $event->sheet->getStyle('A1:J1')->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID);
             $event->sheet->getStyle('A1:J1')->getFill()->getStartColor()->setRGB('febd16');
               $event->sheet->getStyle('A1:J1')->applyFromArray($styleArray);
             $event->sheet->getStyle('A1:J1')->getFont()->getColor()->setARGB(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_BLACK);
             $event->sheet->getRowDimension('1')->setRowHeight(30);
             $event->sheet->getRowDimension('1')->setOutlineLevel(1);
             $event->sheet->getStyle('A1:J1')->getAlignment()->setVertical(\PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER);
             $event->sheet->getStyle('A1:J1')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

             /*$event->sheet->getStyle('A2:G8')->applyFromArray($styleArray);*/
                        
          	},
       ];
   }

    public function headings(): array
    {
        return [
           'Pile Code',
    		   'Location',
    		   'Site',
    		   'Pile type',
    		   'Pile Name',
    		   'Start Time',
    		   'End Time',
    		   'Volume',
    		   'Tonnage',
    		   ' View 3d',
        ];
    }
}