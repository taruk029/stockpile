
<?php $__env->startSection('title', 'Welcome to Dashboard'); ?>
<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('datatables/assets/vendors/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet" type="text/css" />
<style type="text/css">
.dash_img {
  display: block;
  max-width:500px;
  max-height:200px;
  width: auto;
  height: auto;
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- begin:: Subheader -->
<div class="kt-subheader   kt-grid__item" id="kt_subheader">
    <div class="kt-subheader__main">
        <h3 class="kt-subheader__title">
            Dashboard
        </h3>
        </div>

    <div class="kt-subheader__toolbar">
        <div class="kt-subheader__wrapper">
            <a href="#" class="btn kt-subheader__btn-daterange" id="kt_dashboard_daterangepicker" data-toggle="kt-tooltip" title="Today is <?php echo date("d-m-Y"); ?>" data-placement="left">
                <span class="kt-subheader__btn-daterange-title" id="kt_dashboard_daterangepicker_title">Today</span>&nbsp;
                <span class="kt-subheader__btn-daterange-date" id="kt_dashboard_daterangepicker_date"><?php echo date("M d"); ?></span>
            </a>
        </div>
    </div>
</div>
<!-- end:: Subheader -->
<!-- begin:: Content -->
<div class="kt-content kt-grid__item kt-grid__item--fluid" id="kt_content">
    <div class="row">
    <div class="kt-portlet">
    <div class="kt-portlet__body  kt-portlet__body--fit">
    <div class="row row-col-separator-xl">
    <div class="col-md-6 col-lg-6 col-xl-6">
        <center><img src="<?php echo e(asset('assets/media/users/noimage.jpg')); ?>" class="dash_img img-responsive" id="image_one"></center>
    </div>
    <div class="col-md-6 col-lg-6 col-xl-6">
        <center><img src="<?php echo e(asset('assets/media/users/noimage.jpg')); ?>" class="dash_img img-responsive" id="image_two"></center>
    </div>
    </div>
    </div>
    </div>
    </div>
    <div class="row">
        <div class="kt-portlet">
        <div class="kt-portlet__body  kt-portlet__body--fit">
        <div class="row row-col-separator-xl">
        <div class="col-md-12 col-lg-12 col-xl-12">
        <div class="kt-portlet__head kt-portlet__head--lg">
            <div class="kt-portlet__head-label">
            </div>
            <div class="kt-portlet__head-toolbar">
                <div class="kt-portlet__head-wrapper">
                    <div class="kt-portlet__head-actions">
                       &nbsp;
                        <a href="javascript:void(0)" onclick="javascript:s_excel()" class="btn btn-success btn-sm btn-bold">Export To Excel</a>
                    </div>  
                </div>      
            </div>
        </div>
        <table class="table table-striped- table-bordered table-hover table-checkable" id="kt_table_1">
            <thead>
                <tr>
                    <th>Sr. No.</th>
                    <th>Pile Code</th>
                    <th>Location</th>
                    <th>Site</th>
                    <th>Pile type </th>
                    <th>Pile Name </th>
                    <th>Start Time  </th>
                    <th>End Time  </th>
                    <th>Volume</th>
                    <th>Tonnage </th>
                    <th> View 3d  </th>
                    <th> Enquiry  </th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $piles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td><a href="javascript:void(0)" onclick="javascript:load_images(<?php echo e($row->date_metron_id); ?>)" title="Click here to load the images."><?php echo e($row->pile_reference_id); ?></a></td>
                    <td><?php echo e($row->location_name); ?></td>
                    <td><?php echo e($row->site_name); ?></td>
                    <td><?php echo e($row->pile_type); ?></td>
                    <td><?php echo e($row->pile_name); ?></td>
                    <td><?php  $exd = date_create($row->start_time); echo date_format($exd,'h:i:s'); ?></td>
                    <td><?php  $exd = date_create($row->end_time); echo date_format($exd,'h:i:s'); ?></td>
                    <td><?php echo e($row->volume); ?></td>
                    <?php 
                    $tonnage ="BD/Moisture not entered";
                    if($row->volume!="" && $row->moisture && $row->bulk_density) 
                    {
                        $tonnage = (($row->volume*$row->bulk_density)*(1-$row->moisture));
                    }?>
                    <td><?php echo e($tonnage); ?></td>
                    <td><?php if(!empty($row->three_dmodel)): ?>
                        <a href="<?php echo e($row->three_dmodel); ?>" target="_new">Link to 3d Model</a>
                        <?php else: ?>
                            NA
                        <?php endif; ?></td>
                    <td>
                        <a class="btn btn-sm btn-clean" href="javascript:void(0)"  onclick="javascript:open_modal(<?php echo e($row->date_metron_id); ?>)" title="Request Enquiry" >
                            Request Enquiry
                        </a>

                    </td>
                </tr>
              <?php $i++; ?>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
            </tbody>
        </table>
    </div></div></div></div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Set Commission</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>      
        <form action="<?php echo e(url('admin/approve_agent')); ?>" method="post">            
        <?php echo csrf_field(); ?>
      <div class="modal-body">        
        <input type="hidden" class="form-control" id="date_metron_id" name="date_metron_id">
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Commission Percentage:</label>
            <input type="text" class="form-control" id="recipient-name" name="commission">
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="javascript:close_modal()">Close</button>
        <button type="submit" class="btn btn-primary">Approve</button>
      </div>      
        </form>
    </div>
  </div>
</div>
</div>
    <!-- end:: Content -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<!--begin::Page Vendors(used by this page) -->
<script src="<?php echo e(asset('assets/js/demo8/pages/dashboard.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('datatables/assets/vendors/custom/datatables/datatables.bundle.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('datatables/assets/js/demo8/pages/crud/datatables/basic/paginations.js')); ?>" type="text/javascript"></script>

<script>
    function open_modal(id)
    {
        $("#date_metron_id").val(id);
        $("#exampleModal").show();
        $("#exampleModal").removeClass('fade');
    } 
    function close_modal(id)
    {
        $("#exampleModal").hide();
        $("#exampleModal").addClass('fade');
    }    
</script>
<script type="text/javascript">    
    function s_excel()
    {
        /*var month = "";
        var year = "";
        month = $("#month").val();
        year = $("#year").val();
        var query_str = "month="+month+"&year="+year;
        window.open("<?php echo e(url('dashboard_excel/?')); ?>"+query_str);*/
        window.open("<?php echo e(url('pile_excel')); ?>");
    }
</script>
<script type="text/javascript">
function load_images(id)
{
    if(id)
    {
        $.blockUI({ message: "<i class='fa fa-2x fa-spinner fa-spin' aria-hidden='true' ></i> &nbsp; <h6>Loading... a moment please.</h6>" });         
        $.ajax({
            url: "<?php echo e(url('load_images')); ?>",
            type: 'GET',
            data: {id:id},            
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            success:function(data){
                var datas = $.parseJSON(data);
                if(datas)
                {
                    $('#image_one').attr('src',datas.image_one);
                    $('#image_two').attr('src',datas.image_two);
                }
            }
        });
        $.unblockUI();
    }
}
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\stock\resources\views/companies/home.blade.php ENDPATH**/ ?>