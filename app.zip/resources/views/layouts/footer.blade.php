                <!-- begin:: Footer -->
<div class="kt-footer kt-grid__item" id="kt_footer">
    <div class="kt-container">
        <div class="kt-footer__wrapper">
            <div class="kt-footer__copyright">
                <?php echo date("Y"); ?>&nbsp;&copy;&nbsp;<a href="javascript:void(0)" target="_blank" class="kt-link">Stockpile Volume</a>
            </div>
            <div class="kt-footer__menu">
               <!--  <a href="https://kaizentrainingsolutions.com/#mission" target="_blank" class="kt-link">About</a>
                <a href="https://kaizentrainingsolutions.com/#team" target="_blank" class="kt-link">Team</a>
                <a href="https://kaizentrainingsolutions.com/contact/" target="_blank" class="kt-link">Contact</a> -->
            </div>
        </div>
    </div>
</div>
<!-- end:: Footer -->  