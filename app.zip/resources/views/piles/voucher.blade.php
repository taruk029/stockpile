<html>
<head>
    <link rel="stylesheet" href="http://gamarooms.com/public/frontend/css/bootstrap.css">
</head>
<body>
    <div class="container">
            <table style="width:100%; border-collapse: collapse;">
                <tr style="background-color: #354867; color: #ffffff;">
                    <td align="center" style="padding: 20px;">Checkin Date <br><br> 02/29/2021</td>
                    <td align="center" style="padding: 20px;">Checkout Date <br><br> 03/04/2021</td>
                    <td align="center" style="padding: 20px;">Adult(s) <br><br> 2</td>
                    <td align="center" style="padding: 20px;">Child(ren) <br><br> 0</td>
                </tr>
            </table>
            <br>
            <br>
            <table style="width:100%; border-collapse: collapse;">
                <tr style="background-color: #354867; color: #ffffff;">
                    <td align="center" style="padding: 20px;">Checkin Date <br><br> 02/29/2021</td>
                    <td align="center" style="padding: 20px;">Checkout Date <br><br> 03/04/2021</td>
                    <td align="center" style="padding: 20px;">Adult(s) <br><br> 2</td>
                    <td align="center" style="padding: 20px;">Child(ren) <br><br> 0</td>
                </tr>
            </table>
    </div>
</body>
</html>