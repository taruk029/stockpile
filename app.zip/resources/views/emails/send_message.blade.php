<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tbody>
        <tr>
          <td>
              <br><p><strong>Pile Code</strong><br>
              {{$pile}}
          </td>
        </tr>
        <tr>
          <td>
              <br><p><strong>Email</strong><br>
              {{$from}}
          </td>
        </tr>
        <tr>
          <td>
              <br><p><strong>Message</strong><br>
              {{$comment}}
          </td>
        </tr>
        <tr>
          <td><br>Best Regards</td>
        </tr>
        <tr>
          <td>Team StockPile Volume</td> 
        </tr>
      </tbody>
</table>