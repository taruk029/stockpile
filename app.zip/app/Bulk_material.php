<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bulk_material extends Model
{
    //
}
