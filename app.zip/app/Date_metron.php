<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Date_metron extends Model
{
    //
}
